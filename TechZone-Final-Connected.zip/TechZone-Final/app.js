import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

/* =========================================================
   TECHZONE CONFIG
   Put ONLY your Supabase Project URL + PUBLISHABLE key here.
   Never put a secret/service_role key in this file.
   ========================================================= */
const SUPABASE_URL = "https://bkjkwoipgltdmsakkfwb.supabase.co";
const SUPABASE_KEY = "sb_publishable_S7v5UtKIyDQdsf_B2hRrDg_EEOE-0S9";
const ready = SUPABASE_URL.startsWith("https://") && !SUPABASE_KEY.startsWith("YOUR_");
const supabase = ready ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const demo = [
 {id:"demo-1",name:"iPhone 15",brand:"Apple",price:1050000,compare_price:1200000,stock:12,image_url:"https://images.unsplash.com/photo-1592899677977-9c10ca588bbd8?auto=format&fit=crop&w=700&q=80",quality:"Original",category_name:"مۆبایل",rating:4.9,reviews:32},
 {id:"demo-2",name:"HP Laptop 15.6",brand:"HP",price:1150000,compare_price:1290000,stock:8,image_url:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=700&q=80",quality:"New",category_name:"کۆمپیوتەر و لەپتۆپ",rating:4.7,reviews:24},
 {id:"demo-3",name:"AirPods Pro 2",brand:"Apple",price:650000,compare_price:760000,stock:20,image_url:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=80",quality:"Original",category_name:"گوێگر",rating:4.8,reviews:18},
 {id:"demo-4",name:"PlayStation 5",brand:"Sony",price:1250000,compare_price:0,stock:5,image_url:"https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=700&q=80",quality:"New",category_name:"گیمینگ",rating:4.9,reviews:27}
];
const cats = [
 {id:"c1",name:"مۆبایل",icon:"📱",slug:"mobile"},{id:"c2",name:"کۆمپیوتەر و لەپتۆپ",icon:"💻",slug:"laptop"},
 {id:"c3",name:"گوێگر و ئاکسسوارات",icon:"🎧",slug:"audio"},{id:"c4",name:"سەعات",icon:"⌚",slug:"watch"},
 {id:"c5",name:"گیمینگ",icon:"🎮",slug:"gaming"},{id:"c6",name:"ماڵی زیرەک",icon:"🏠",slug:"smart-home"}
];

const money = n => Number(n||0).toLocaleString("en-US")+" IQD";
const esc = s => String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const qs = s => new URLSearchParams(location.search).get(s);

window.notify = msg => { const t=document.getElementById("toast"); if(t){t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);} };
window.toggleMenu=()=>document.getElementById("navLinks")?.classList.toggle("open");
window.searchProducts=()=>{const q=document.getElementById("searchInput")?.value.trim(); location.href=q?`shop.html?q=${encodeURIComponent(q)}`:"shop.html";};
window.addToCart = p => { let c=JSON.parse(localStorage.getItem("tz_cart")||"[]"); const x=c.find(i=>i.id===p.id); x?x.qty++:c.push({...p,qty:1}); localStorage.setItem("tz_cart",JSON.stringify(c)); updateCartCount(); notify("بەرهەمەکە خرایە ناو سەبەتە."); };
window.removeFromCart=id=>{let c=cart().filter(x=>x.id!==id);localStorage.setItem("tz_cart",JSON.stringify(c));renderCart();updateCartCount();};
window.changeQty=(id,d)=>{let c=cart();const x=c.find(i=>i.id===id);if(x){x.qty=Math.max(1,x.qty+d)}localStorage.setItem("tz_cart",JSON.stringify(c));renderCart();updateCartCount();};
const cart=()=>JSON.parse(localStorage.getItem("tz_cart")||"[]");
function updateCartCount(){document.querySelectorAll("#cartCount").forEach(e=>e.textContent=cart().reduce((a,x)=>a+x.qty,0));}
function productCard(p){
 return `<article class="product-card"><a href="product.html?id=${encodeURIComponent(p.id)}" class="product-img"><img src="${esc(p.image_url||"https://images.unsplash.com/photo-1468495244123-6c6c332eeece?auto=format&fit=crop&w=700&q=80")}" loading="lazy"><span class="tag">${p.stock>0?"نوێ":"نەماوە"}</span></a><div class="product-body"><small>${esc(p.brand||"TechZone")}</small><h3>${esc(p.name)}</h3><p class="meta">${esc(p.quality||"Original")} · ⭐ ${Number(p.rating||5).toFixed(1)} (${p.reviews||0})</p><div class="price">${money(p.price)} ${p.compare_price?`<del>${money(p.compare_price)}</del>`:""}</div><button class="btn primary wide" onclick='addToCart(${JSON.stringify(p).replace(/'/g,"&#39;")})'>🛒 زیادکردن بۆ سەبەتە</button></div></article>`;
}
async function getProducts(filters={}){
 if(!ready) return demo.filter(p=>!filters.q||p.name.toLowerCase().includes(filters.q.toLowerCase()));
 let q=supabase.from("products").select("*, categories(name)").eq("is_active",true);
 if(filters.q) q=q.or(`name.ilike.%${filters.q}%,brand.ilike.%${filters.q}%`);
 if(filters.brand) q=q.ilike("brand",`%${filters.brand}%`);
 if(filters.category) q=q.eq("category_id",filters.category);
 if(filters.min) q=q.gte("price",filters.min);
 if(filters.max) q=q.lte("price",filters.max);
 const {data,error}=await q.order("created_at",{ascending:false});
 if(error){console.error(error);notify("پەیوەندی بە داتابەیس هەڵەی هەیە.");return [];}
 return (data||[]).map(p=>({...p,category_name:p.categories?.name||""}));
}
async function loadHome(){
 const cg=document.getElementById("categoriesGrid"); if(cg) cg.innerHTML=cats.map(c=>`<a class="category-card" href="shop.html?category=${c.id}"><b>${c.icon}</b><span>${c.name}</span></a>`).join("");
 const pg=document.getElementById("productsGrid"); if(!pg)return;
 const ps=await getProducts(); pg.innerHTML=ps.slice(0,4).map(productCard).join("")||"<div class='empty'>هیچ بەرهەمێک نییە.</div>";
}
async function loadShop(){
 const pg=document.getElementById("productsGrid");if(!pg)return;
 const catsEl=document.getElementById("categoryFilter");
 if(catsEl && catsEl.options.length===1) catsEl.innerHTML='<option value="">هەموو جۆرەکان</option>'+cats.map(c=>`<option value="${c.id}">${c.name}</option>`).join("");
 const q=qs("q")||document.getElementById("searchInput")?.value||"";
 const category=qs("category")||document.getElementById("categoryFilter")?.value||"";
 const ps=await getProducts({q,category,brand:document.getElementById("brandFilter")?.value,min:document.getElementById("minPrice")?.value,max:document.getElementById("maxPrice")?.value});
 pg.innerHTML=ps.map(productCard).join("")||"<div class='empty'>بەرهەمێکی گونجاو نەدۆزرایەوە.</div>";
}
window.resetFilters=()=>{["brandFilter","minPrice","maxPrice"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""});const c=document.getElementById("categoryFilter");if(c)c.value="";loadShop();};

async function loadProduct(){
 const box=document.getElementById("productView");if(!box)return;
 const id=qs("id");let p;
 if(ready){const {data,error}=await supabase.from("products").select("*, categories(name)").eq("id",id).single();if(!error&&data)p={...data,category_name:data.categories?.name||""};}
 if(!p)p=demo.find(x=>x.id===id)||demo[0];
 box.innerHTML=`<div class="product-detail"><div class="gallery"><img src="${esc(p.image_url)}"></div><div class="detail-copy"><span class="eyebrow">${esc(p.category_name||"TechZone")}</span><h1>${esc(p.name)}</h1><p class="brandline">${esc(p.brand||"")} · ${esc(p.quality||"Original")}</p><div class="rating">★★★★★ <span>${p.reviews||0} هەڵسەنگاندن</span></div><p class="description">${esc(p.description||"بەرهەمێکی کوالیتی بۆ بەکارهێنانی ڕۆژانە، لەگەڵ گەرەنتی و پشتیوانی TechZone.")}</p><div class="detail-price">${money(p.price)} ${p.compare_price?`<del>${money(p.compare_price)}</del>`:""}</div><div class="stock">${p.stock>0?"● بەردەستە":"● نەماوە"} — ${p.stock||0} دانە</div><button class="btn primary big" id="detailAdd">🛒 زیادکردن بۆ سەبەتە</button><a class="btn ghost big" href="cart.html">بینینی سەبەتە</a></div></div>`;
 document.getElementById("detailAdd").onclick=()=>addToCart(p);
}
function renderCart(){
 const box=document.getElementById("cartView");if(!box)return;const c=cart();
 if(!c.length){box.innerHTML=`<div class="empty bigEmpty"><div>🛒</div><h2>سەبەتەکەت بەتاڵە</h2><a class="btn primary" href="shop.html">دەستپێکردنی کڕین</a></div>`;return;}
 const subtotal=c.reduce((a,x)=>a+x.price*x.qty,0);
 box.innerHTML=`<div class="cart-layout"><section class="panel cart-items">${c.map(x=>`<div class="cart-item"><img src="${esc(x.image_url)}"><div><h3>${esc(x.name)}</h3><small>${esc(x.brand||"")}</small><strong>${money(x.price)}</strong></div><div class="qty"><button onclick="changeQty('${x.id}',-1)">−</button><b>${x.qty}</b><button onclick="changeQty('${x.id}',1)">+</button></div><button class="remove" onclick="removeFromCart('${x.id}')">✕</button></div>`).join("")}</section><aside class="panel summary"><h2>کورتەی داواکاری</h2><div><span>کۆی نرخ</span><b>${money(subtotal)}</b></div><div><span>گەیاندن</span><b>خۆڕایی</b></div><hr><div class="total"><span>کۆی گشتی</span><b>${money(subtotal)}</b></div><a class="btn primary wide" href="checkout.html">بەردەوامبوون بۆ کڕین</a></aside></div>`;
}
async function renderCheckout(){
 const box=document.getElementById("checkoutSummary");if(!box)return;const c=cart();const total=c.reduce((a,x)=>a+x.price*x.qty,0);
 box.innerHTML=`<h2>کورتەی سەبەتە</h2>${c.map(x=>`<div class="summary-row"><span>${esc(x.name)} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join("")}<hr><div class="total"><span>کۆی گشتی</span><b>${money(total)}</b></div>`;
 document.getElementById("checkoutForm")?.addEventListener("submit",async e=>{e.preventDefault();if(!c.length)return notify("سەبەتە بەتاڵە.");const f=new FormData(e.target);if(ready){const {data:{user}}=await supabase.auth.getUser();const {data:order,error}=await supabase.from("orders").insert({user_id:user?.id||null,customer_name:f.get("name"),phone:f.get("phone"),city:f.get("city"),address:f.get("address"),payment_method:f.get("payment"),status:"pending",total_amount:total}).select().single();if(error){notify("نەتوانرا داواکاری تۆمار بکرێت.");return;}await supabase.from("order_items").insert(c.map(x=>({order_id:order.id,product_id:String(x.id).match(/^demo-/)?null:x.id,product_name:x.name,quantity:x.qty,unit_price:x.price,total_price:x.price*x.qty})));}
 localStorage.removeItem("tz_cart");notify("داواکارییەکەت بە سەرکەوتوویی نێردرا.");setTimeout(()=>location.href="index.html",1200);});
}
async function login(){
 document.getElementById("loginForm")?.addEventListener("submit",async e=>{e.preventDefault();if(!ready)return notify("سەرەتا Supabase URL و Publishable Key زیاد بکە.");const f=new FormData(e.target);const {error}=await supabase.auth.signInWithPassword({email:f.get("email"),password:f.get("password")});if(error)return notify(error.message);location.href="admin.html";});
}
async function adminLogout(){if(ready)await supabase.auth.signOut();location.href="login.html"} window.adminLogout=adminLogout;
async function loadAdmin(){
 if(!document.getElementById("adminProducts"))return;
 if(!ready)return notify("Supabase config هێشتا دانەنراوە.");
 const {data:{user}}=await supabase.auth.getUser();if(!user){location.href="login.html";return;}
 document.getElementById("adminUser").textContent=user.email;
 const [{data:ps},{data:os}]=await Promise.all([supabase.from("products").select("*").order("created_at",{ascending:false}),supabase.from("orders").select("*").order("created_at",{ascending:false})]);
 document.getElementById("statProducts").textContent=ps?.length||0;document.getElementById("statOrders").textContent=os?.length||0;document.getElementById("statStock").textContent=(ps||[]).reduce((a,x)=>a+Number(x.stock||0),0);document.getElementById("statSales").textContent=money((os||[]).reduce((a,x)=>a+Number(x.total_amount||0),0));
 document.getElementById("adminProducts").innerHTML=`<table><tr><th>بەرهەم</th><th>نرخ</th><th>کۆگا</th><th></th></tr>${(ps||[]).map(p=>`<tr><td>${esc(p.name)}</td><td>${money(p.price)}</td><td>${p.stock}</td><td><button class="danger" onclick="deleteProduct('${p.id}')">سڕینەوە</button></td></tr>`).join("")}</table>`;
 document.getElementById("adminOrders").innerHTML=`<table><tr><th>کڕیار</th><th>مبلغ</th><th>دۆخ</th></tr>${(os||[]).map(o=>`<tr><td>${esc(o.customer_name||"—")}<small>${esc(o.phone||"")}</small></td><td>${money(o.total_amount)}</td><td><span class="badge">${esc(o.status)}</span></td></tr>`).join("")}</table>`;
}
window.deleteProduct=async id=>{if(!confirm("ئەم بەرهەمە بسڕینەوە؟"))return;const {error}=await supabase.from("products").delete().eq("id",id);if(error)notify("سڕینەوە ڕێگەپێنەدرا.");else{notify("سڕایەوە.");loadAdmin();}};
async function bindAdminForm(){document.getElementById("productForm")?.addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.target);const row={name:f.get("name"),brand:f.get("brand"),price:Number(f.get("price")),stock:Number(f.get("stock")||0),image_url:f.get("image_url"),description:f.get("description"),is_active:true};const {error}=await supabase.from("products").insert(row);if(error)notify("زیادکردن سەرکەوتوو نەبوو: "+error.message);else{notify("بەرهەم زیادکرا.");e.target.reset();loadAdmin();}});}

updateCartCount();loadHome();loadShop();loadProduct();renderCart();renderCheckout();login();loadAdmin();bindAdminForm();
