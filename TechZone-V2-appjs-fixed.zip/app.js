/* TechZone V2 Premium - app.js */
const SUPABASE_URL = "https://bkjkwoipgltdmsakkfwb.supabase.co";
const SUPABASE_KEY = "sb_publishable_S7v5UtKIyDQdsf_B2hRrDg_EEOE-0S9";

let supabaseClient = null;
try {
  if (window.supabase?.createClient) {
    supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
  }
} catch (error) {
  console.warn("Supabase initialization failed:", error);
}

const demoProducts = [
  {id:"p1", name:"iPhone 17 Pro", brand:"Apple", category:"Mobile", price:1499000, old_price:1599000, rating:4.9, stock:12, image:"https://images.unsplash.com/photo-1592286927505-2fd7d7c6f5d4?auto=format&fit=crop&w=900&q=85"},
  {id:"p2", name:"MacBook Pro", brand:"Apple", category:"Laptop", price:2399000, old_price:2599000, rating:4.8, stock:8, image:"https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=85"},
  {id:"p3", name:"Sony WH-1000XM5", brand:"Sony", category:"Headphones", price:399000, old_price:449000, rating:4.8, stock:15, image:"https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=85"},
  {id:"p4", name:"Galaxy S25 Ultra", brand:"Samsung", category:"Mobile", price:1299000, old_price:1399000, rating:4.7, stock:10, image:"https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=900&q=85"}
];

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const money = n => new Intl.NumberFormat("en-US").format(Number(n||0)) + " IQD";

function getCart(){
  try { return JSON.parse(localStorage.getItem("techzone_cart") || "[]"); }
  catch { return []; }
}
function saveCart(cart){
  localStorage.setItem("techzone_cart", JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount(){
  const count = getCart().reduce((sum,p)=>sum + Number(p.qty||1),0);
  $$(".cart-count").forEach(el => el.textContent = count);
}
function addToCart(product, qty=1){
  const cart=getCart();
  const found=cart.find(p=>String(p.id)===String(product.id));
  if(found) found.qty=(found.qty||1)+qty;
  else cart.push({...product,qty});
  saveCart(cart);
  alert("بەرهەمەکە زیادکرا بۆ سەبەتە 🛒");
}
function removeFromCart(id){
  saveCart(getCart().filter(p=>String(p.id)!==String(id)));
  renderCart();
}
function cartTotal(){ return getCart().reduce((s,p)=>s+Number(p.price||0)*Number(p.qty||1),0); }

async function loadProducts(){
  if(!supabaseClient) return demoProducts;
  try{
    const {data,error}=await supabaseClient.from("products").select("*").order("created_at",{ascending:false});
    if(!error && data?.length) return data;
  }catch(e){ console.warn(e); }
  return demoProducts;
}

function productCard(p){
  return `<article class="product-card">
    <a href="product.html?id=${encodeURIComponent(p.id)}" class="product-image">
      <img src="${p.image || p.image_url || "https://via.placeholder.com/700x700?text=TechZone"}" alt="${p.name||"Product"}">
    </a>
    <div class="product-info">
      <small>${p.brand||"TechZone"}</small>
      <h3>${p.name||"Product"}</h3>
      <div class="rating">★ ${p.rating||"4.8"}</div>
      <strong>${money(p.price)}</strong>
      ${p.old_price ? `<del>${money(p.old_price)}</del>` : ""}
      <button class="btn add-cart" data-product='${JSON.stringify(p).replace(/'/g,"&#39;")}'>زیادکردن بۆ سەبەتە</button>
    </div>
  </article>`;
}

async function renderHome(){
  const target=$("#featured-products") || $("#products-grid");
  if(!target) return;
  const products=await loadProducts();
  target.innerHTML=products.map(productCard).join("");
  bindProductButtons();
}
function bindProductButtons(){
  $$(".add-cart").forEach(btn=>btn.onclick=()=>{
    try { addToCart(JSON.parse(btn.dataset.product.replace(/&#39;/g,"'"))); } catch {}
  });
}

async function renderShop(){
  const target=$("#products-grid");
  if(!target) return;
  let products=await loadProducts();
  const q=($("#search-input")?.value || new URLSearchParams(location.search).get("q") || "").toLowerCase();
  if(q) products=products.filter(p=>`${p.name} ${p.brand} ${p.category}`.toLowerCase().includes(q));
  target.innerHTML=products.map(productCard).join("");
  bindProductButtons();
}

async function renderProduct(){
  const id=new URLSearchParams(location.search).get("id");
  const p=(await loadProducts()).find(x=>String(x.id)===String(id)) || demoProducts[0];
  const root=$("#product-detail");
  if(!root) return;
  root.innerHTML=`<div class="detail-image"><img src="${p.image||p.image_url}" alt="${p.name}"></div>
  <div class="detail-info"><small>${p.brand||""}</small><h1>${p.name}</h1>
  <div class="rating">★ ${p.rating||4.8}</div><h2>${money(p.price)}</h2>
  <p>بەرهەمێکی کوالێتی بۆ بەکارهێنانی ڕۆژانە. گەرەنتی و پشتیوانی TechZone بەردەستە.</p>
  <button class="btn add-detail">زیادکردن بۆ سەبەتە 🛒</button></div>`;
  $(".add-detail",root)?.addEventListener("click",()=>addToCart(p));
}

function renderCart(){
  const root=$("#cart-items"), total=$("#cart-total");
  if(!root) return;
  const cart=getCart();
  root.innerHTML=cart.length ? cart.map(p=>`<div class="cart-item">
    <img src="${p.image||p.image_url}" alt="${p.name}">
    <div><h3>${p.name}</h3><p>${money(p.price)} × ${p.qty||1}</p></div>
    <button class="btn" onclick="removeFromCart('${p.id}')">سڕینەوە</button>
  </div>`).join("") : "<p>سەبەتەکە بەتاڵە.</p>";
  if(total) total.textContent=money(cartTotal());
}

function setupSearch(){
  const form=$("#search-form"), input=$("#search-input");
  if(form) form.addEventListener("submit",e=>{
    e.preventDefault(); location.href="shop.html?q="+encodeURIComponent(input?.value||"");
  });
}

document.addEventListener("DOMContentLoaded",()=>{
  updateCartCount();
  setupSearch();
  renderHome();
  renderShop();
  renderProduct();
  renderCart();
});
